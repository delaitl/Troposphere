import pandas
colnames = ['siteNum', 'satNum', 'fre[GHz]', 'elev', 'proba_elev', 'att_oxy']
data = pandas.read_csv('attenuation_oxygen_37.csv', names=colnames)

ELEV = data.elev.tolist()
PROBA = data.proba_elev.tolist()
ATTENUATION = data.att_oxy.tolist()

print(PROBA)