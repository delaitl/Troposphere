import pandas
import matplotlib.pyplot as plt


colnames = ['siteNum', 'satNum', 'fre[GHz]', 'elev', 'proba_elev', 'att_oxy']

data = pandas.read_csv('attenuation_oxygen_37.csv', names=colnames)
ELEV37 = data.elev.tolist()
ATTENUATION37 = data.att_oxy.tolist()

data = pandas.read_csv('attenuation_oxygen_75.csv', names=colnames)
ELEV75 = data.elev.tolist()
ATTENUATION75 = data.att_oxy.tolist()

data = pandas.read_csv('attenuation_vapor_37.csv', names=colnames)
ELEV37V = data.elev.tolist()
ATTENUATION37V = data.att_oxy.tolist()
import pandas
import matplotlib.pyplot as plt


colnames = ['siteNum', 'satNum', 'fre[GHz]', 'elev', 'proba_elev', 'att_oxy']

data = pandas.read_csv('attenuation_oxygen_37.csv', names=colnames)
ELEV37 = data.elev.tolist()
ATTENUATION37 = data.att_oxy.tolist()

data = pandas.read_csv('attenuation_oxygen_75.csv', names=colnames)
ELEV75 = data.elev.tolist()
ATTENUATION75 = data.att_oxy.tolist()

data = pandas.read_csv('attenuation_vapor_37.csv', names=colnames)
ELEV37V = data.elev.tolist()
ATTENUATION37V = data.att_oxy.tolist()

data = pandas.read_csv('attenuation_vapor_75.csv', names=colnames)
ELEV75V = data.elev.tolist()
ATTENUATION75V = data.att_oxy.tolist()

x = ELEV75
y1 = ATTENUATION37
y2 = ATTENUATION75
y3= ATTENUATION37V
y4 = ATTENUATION75V

plt.plot(x, y2,label='Oxygen - 75 GHz')
plt.plot(x, y4,label='Vapor - 75 GHz')
plt.plot(x, y1,label='Oxygen - 37.5 GHz')
plt.plot(x, y3,label='Vapor - 37.5 GHz')

plt.xlabel("Elevation Angle(deg)")
plt.ylabel("Attenuation (dB)")
plt.legend();
plt.title('Attenuation due to Gases - Isfjord (Norway)')
plt.grid(True)
plt.show()

